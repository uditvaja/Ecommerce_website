import React from 'react'
import Navbar from './Navbar'

const PageFof = () => {
  return (
    <div>
      page 404
<Navbar/>
    </div>
  )
}

export default PageFof
