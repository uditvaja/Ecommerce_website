import React from 'react'
import Navbar from './Navbar'

const Cart = () => {
  return (
    <div>
      <p>cart</p>
<Navbar/>
    </div>
  )
}

export default Cart
