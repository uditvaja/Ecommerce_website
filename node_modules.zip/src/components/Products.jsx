import React from 'react'


const Products = () => {
  return (
    <div>
      <p>products</p>
    </div>
  )
}

export default Products
