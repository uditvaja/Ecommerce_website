import React from 'react'
import './Productcontainer.css'
import { Link } from 'react-router-dom';
const Productcontainer = (product) => {
    // console.log(p)
   
const imageUrl=product.product.prodimage;
let description = product.product.description;
let title= product.product.brand;
console.log("imggggg",imageUrl);
    return (
      <>

       {/* <div className="product-box">
      <div className="product-image-container">
        <img src={imageUrl} alt={title} className="product-image" />
      </div>
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-description">{description}</p>
        <p className="product-price">₹277</p>
        <button className="add-to-cart-button">Add to Cart</button>
      </div>
      </div> */}
      <div className="product-box">
      <img src={imageUrl} alt={title} className="product-image" />
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-price">$233</p>
        <button className="buy-button">Buy Now</button>
      </div>
    </div>
    <div className="product-box">
      <img src={imageUrl} alt={title} className="product-image" />
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-price">$233</p>
        <button className="buy-button">Buy Now</button>
      </div>
    </div>
    <div className="product-box">
      <img src={imageUrl} alt={title} className="product-image" />
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-price">$233</p>
        <button className="buy-button">Buy Now</button>
      </div>
    </div>
    <div className="product-box">
      <img src={imageUrl} alt={title} className="product-image" />
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-price">$233</p>
        <button className="buy-button">Buy Now</button>
      </div>
    </div>
    <div className="product-box">
      <img src={imageUrl} alt={title} className="product-image" />
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-price">$233</p>
        <button className="buy-button">Buy Now</button>
      </div>
    </div>
    <div className="product-box">
      <img src={imageUrl} alt={title} className="product-image" />
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-price">$233</p>
        <button className="buy-button">Buy Now</button>
      </div>
    </div>
    <div className="product-box">
      <img src={imageUrl} alt={title} className="product-image" />
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-price">$233</p>
        <button className="buy-button">Buy Now</button>
      </div>
    </div>
    <div className="product-box">
      <img src={imageUrl} alt={title} className="product-image" />
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-price">$233</p>
        <button className="buy-button">Buy Now</button>
      </div>
    </div>
    <div className="product-box">
      <img src={imageUrl} alt={title} className="product-image" />
      <div className="product-details">
        <h2 className="product-title">{title}</h2>
        <p className="product-price">$233</p>
        <button className="buy-button">Buy Now</button>
      </div>
    </div>
       
    


    

 
      </>
    )
}

export default Productcontainer